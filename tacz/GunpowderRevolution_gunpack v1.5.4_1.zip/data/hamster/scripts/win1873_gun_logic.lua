local M = {}

-- Win1873 使用独立逻辑机，避免修改 Win1894 的三发填弹条逻辑。
local LOADING_PIPE_ROUNDS = 7
local FLAPPER_DEVICE = "hamster:m1873_flapper_device"

function M.shoot(api)
    api:shootOnce(api:isShootingNeedConsumeAmmo())

    -- The flapper device cycles the lever and chambers the next round as part
    -- of the firing action, so TacZ never needs to enter the manual bolt cycle.
    if (api:getAttachment("STOCK") == FLAPPER_DEVICE) then
        if (api:removeAmmoFromMagazine(1) ~= 0) then
            api:setAmmoInBarrel(true)
        end
        return false
    end

    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            shoot_mode = 0
        }
    end
    if (api:getAimingProgress() == 0) then
        cache.shoot_mode = 1
    else
        cache.shoot_mode = 0
    end
    api:cacheScriptData(cache)
end

function M.start_bolt(api)
    -- Return true to start ticking, since there are nothing needed to be check
    return true
end

function M.tick_bolt(api)
    local cache = api:getCachedScriptData()
    -- Get total bolt time from script parameter in gun data
    local total_bolt_time = api:getScriptParams().bolt_time * 1000

    if (cache ~= nil) then
        -- 如果当前是腰射状态，则赋值覆盖掉原来的拉栓时长数据
        if (cache.shoot_mode ~= nil and cache.shoot_mode == 1 and api:getFireMode() == AUTO) then
            total_bolt_time = api:getScriptParams().rapid_bolt_time * 1000
        end
    end

    if (total_bolt_time == nil) then
        return false
    end
    if (api:getBoltTime() < total_bolt_time) then
        -- Bolt time less than total means we need to keep ticking, return true
        return true
    else
        -- Bolt time greater than total means that the bullet
        -- needs to be put from the magazine into the barrel, and then return false to end ticking.
        if (api:removeAmmoFromMagazine(1) ~= 0) then
            api:setAmmoInBarrel(true);
        end
        return false
    end
end

function M.start_reload(api)
    -- Initialize cache that will be used in reload ticking
    local cache = {
        reloaded_count = 0,
        needed_count = api:getNeededAmmoAmount(),
        is_tactical = api:getReloadStateType() == TACTICAL_RELOAD_FEEDING,
        interrupted_time = -1,
    }
    api:cacheScriptData(cache)
    -- Return true to start ticking
    return true
end

local function getReloadTimingFromParam(param)
    -- Need to convert time from seconds to milliseconds
    local intro = param.intro * 1000
    local intro_empty = param.intro_empty * 1000
    local loop = param.loop * 1000
    local ending = param.ending * 1000
    local ending_empty = param.ending_empty * 1000
    local ending_empty_feed = param.ending_empty_feed * 1000
    local loop_feed = param.loop_feed * 1000
    local pipe_load = param.pipe_load * 1000
    local pipe_load_feed = param.pipe_load_feed * 1000
    -- Check if any timing is nil
    if (intro == nil or intro_empty == nil or loop == nil or ending == nil or ending_empty == nil or ending_empty_feed == nil or loop_feed == nil or pipe_load == nil or pipe_load_feed == nil) then
        return nil
    end
    return intro, intro_empty, loop, ending, ending_empty, ending_empty_feed, loop_feed, pipe_load, pipe_load_feed
end

function M.tick_reload(api)
    -- Get all timings from script parameter in gun data
    local param = api:getScriptParams();
    local intro, intro_empty, loop, ending, ending_empty, ending_empty_feed, loop_feed, pipe_load, pipe_load_feed = getReloadTimingFromParam(param)
    -- Get reload time (The time from the start of reloading to the current time) from api
    local reload_time = api:getReloadTime()
    -- Get cache from api, it will be used to count loaded ammo, mark reload interruptions, etc.
    local cache = api:getCachedScriptData()
    local interrupted_time = cache.interrupted_time
    -- Handle interrupting reload
    if (cache.interrupted_time ~= -1) then
        local int_time = reload_time - cache.interrupted_time
        if (not cache.is_tactical) then
            if (int_time > ending_empty_feed) then
                if(not api:hasAmmoInBarrel()) then
                    if (api:removeAmmoFromMagazine(1) ~= 0) then
                        api:setAmmoInBarrel(true);
                    end
                end
            end
            if(int_time >= ending_empty) then
               return NOT_RELOADING, -1
            else
               return EMPTY_RELOAD_FINISHING, ending - int_time
            end
        else
            if(int_time >= ending) then
               return NOT_RELOADING, -1
            else
                return TACTICAL_RELOAD_FINISHING, ending - int_time
            end
        end
    else
        if (not api:hasAmmoToConsume()) then
            interrupted_time = api:getReloadTime()
        end
    end

    local reloaded_count = cache.reloaded_count;
    -- Load the ammo into the magazine one by one
    if (reloaded_count >= 0) then
        local base_time = reloaded_count * loop
        if(reloaded_count >= LOADING_PIPE_ROUNDS and api:getMagExtentLevel() == 1) then
            base_time = (math.floor(reloaded_count / LOADING_PIPE_ROUNDS) * pipe_load) + (reloaded_count % LOADING_PIPE_ROUNDS) * loop
        end
        if (cache.needed_count - reloaded_count >= LOADING_PIPE_ROUNDS and api:getMagExtentLevel() == 1) then
            base_time = base_time + pipe_load_feed
        else
            base_time = base_time + loop_feed
        end
        if (not cache.is_tactical) then
            base_time = base_time + intro_empty
        else
            base_time = base_time + intro
        end
        while (base_time < reload_time) do
            if (reloaded_count > cache.needed_count) then
                break
            end
            if (cache.needed_count - reloaded_count >= LOADING_PIPE_ROUNDS and api:getMagExtentLevel() == 1) then
                reloaded_count = reloaded_count + LOADING_PIPE_ROUNDS
                base_time = base_time + pipe_load
                api:putAmmoInMagazine(api:isReloadingNeedConsumeAmmo() and api:consumeAmmoFromPlayer(LOADING_PIPE_ROUNDS) or LOADING_PIPE_ROUNDS)
            else
                reloaded_count = reloaded_count + 1
                base_time = base_time + loop
                api:consumeAmmoFromPlayer(1)
                api:putAmmoInMagazine(1)
            end
        end
    end

    -- Write back cache
    if (reloaded_count >= cache.needed_count) then
        interrupted_time = api:getReloadTime() - loop_feed + loop
    end
    cache.interrupted_time = interrupted_time
    cache.reloaded_count = reloaded_count
    api:cacheScriptData(cache)
    -- return reloadstate
    local total_time = cache.needed_count * loop
    if (not cache.is_tactical) then
        total_time = total_time + intro_empty
        return EMPTY_RELOAD_FEEDING, total_time - reload_time
    else
        total_time = total_time + intro
        return TACTICAL_RELOAD_FEEDING, total_time - reload_time
    end
end

function M.interrupt_reload(api)
    local cache = api:getCachedScriptData()
    if (cache ~= nil and cache.interrupted_time == -1) then
        cache.interrupted_time = api:getReloadTime()
    end
end

return M
