local M = {}

local function hasSeparateChamber(api)
    local capacity = api:getMaxAmmoCount()
    return capacity == 4 or capacity == 9 or capacity == 19
end

function M.shoot(api)
    api:shootOnce(api:isShootingNeedConsumeAmmo())
end

function M.start_bolt(api)
    return true
end

function M.tick_bolt(api)
    -- 从data中获取拉栓所需的时间
    local total_bolt_time = api:getScriptParams().bolt_time * 1000
    if (total_bolt_time == nil) then
        return false
    end
    -- 获取并检查从开始拉栓到现在的时间
    if (api:getBoltTime() < total_bolt_time) then
        -- 还未到达所需时间时，返回true，使拉栓函数继续循环执行
        return true
    else
        -- 大于所需时间时也即是拉栓完成时
        -- 从弹匣中扣除一颗子弹，其返回值是成功扣除子弹的数量。
        if (not api:hasAmmoInBarrel() and api:removeAmmoFromMagazine(1) ~= 0) then
        -- 返回数量不为0则意味着成功扣除，弹匣中子弹数不为空，因此设置枪膛内具有子弹
            api:setAmmoInBarrel(true);
        end
        -- 返回false来结束拉栓函数循环
        return false
    end
end

function M.start_reload(api)
    -- Initialize cache that will be used in reload ticking
    local cache = {
        reloaded_count = 0,
        needed_count = api:getNeededAmmoAmount(),
        is_tactical = api:getReloadStateType() == TACTICAL_RELOAD_FEEDING,
        interrupted_time = -1,
    }
    -- Standard and extended magazines reserve one round for the chamber.
    if (hasSeparateChamber(api)) then
        if (not api:hasAmmoInBarrel()) then
            cache.needed_count = cache.needed_count + 1
        end
    elseif(api:hasAmmoInBarrel())then
        cache.needed_count = cache.needed_count - 1
    end
    api:cacheScriptData(cache)
    -- Return true to start ticking
    return true
end

local function getReloadTimingFromParam(param)
    -- Need to convert time from seconds to milliseconds
    local intro = param.intro * 1000
    local intro_empty = param.intro_empty * 1000
    local intro_empty_clip = param.intro_empty_clip * 1000
    local loop = param.loop * 1000
    local ending = param.ending * 1000
    local ending_empty = param.ending_empty * 1000
    local ending_empty_feed = param.ending_empty_feed * 1000
    local clip_load = param.clip_load * 1000
    local clip_load_feed = param.clip_load_feed * 1000
    local loop_feed = param.loop_feed * 1000
    -- Check if any timing is nil
    if (intro == nil or intro_empty == nil or intro_empty_clip == nil or loop == nil or ending == nil or ending_empty == nil or ending_empty_feed == nil or clip_load == nil or clip_load_feed == nil or loop_feed == nil) then
        return nil
    end
    return intro, intro_empty, intro_empty_clip, loop, ending, ending_empty, ending_empty_feed, clip_load, clip_load_feed, loop_feed
end

function M.tick_reload(api)
    -- Get all timings from script parameter in gun data
    local param = api:getScriptParams();
    local intro, intro_empty, intro_empty_clip, loop, ending, ending_empty, ending_empty_feed, clip_load, clip_load_feed, loop_feed = getReloadTimingFromParam(param)
    -- Get reload time (The time from the start of reloading to the current time) from api
    local reload_time = api:getReloadTime()
    -- Get cache from api, it will be used to count loaded ammo, mark reload interruptions, etc.
    local cache = api:getCachedScriptData()
    local interrupted_time = cache.interrupted_time
    -- Handle interrupting reload
    if (cache.interrupted_time ~= -1) then
        local int_time = reload_time - cache.interrupted_time
        if (not cache.is_tactical) then
            if (int_time > ending_empty_feed) then
                if(not api:hasAmmoInBarrel()) then
                    if (api:removeAmmoFromMagazine(1) ~= 0) then
                        api:setAmmoInBarrel(true);
                    end
                end
            end
            if(int_time >= ending_empty) then
               return NOT_RELOADING, -1
            else
               return EMPTY_RELOAD_FINISHING, ending_empty - int_time
            end
        else
            if(int_time >= ending) then
               return NOT_RELOADING, -1
            else
                return TACTICAL_RELOAD_FINISHING, ending - int_time
            end
        end
    else
        if (not api:hasAmmoToConsume()) then
            interrupted_time = math.max(reload_time, cache.completed_load_time or 0)
        end
    end

    local reloaded_count = cache.reloaded_count;
    -- Keep cycle timing separate from the number of rounds actually consumed.
    if (interrupted_time == -1) then
        local base_time = cache.completed_load_time
        if (base_time == nil) then
            if (not cache.is_tactical) then
                if (api:getAttachment("SCOPE") == "tacz:empty" or api:getMaxAmmoCount() > 5) then
                    base_time = intro_empty_clip
                else
                    base_time = intro_empty
                end
            else
                base_time = intro
            end
        end
        while (reloaded_count < cache.needed_count) do
            local use_clip = cache.needed_count - reloaded_count >= 5 and api:getAttachment("SCOPE") == "tacz:empty"
            local feed_time = use_clip and clip_load_feed or loop_feed
            local load_time = use_clip and clip_load or loop
            if (reload_time <= base_time + feed_time) then
                break
            end
            local requested = use_clip and 5 or 1
            local consumed = api:isReloadingNeedConsumeAmmo() and api:consumeAmmoFromPlayer(requested) or requested
            if (consumed <= 0) then
                interrupted_time = reload_time
                break
            end
            local magazine_rounds = consumed
            -- Account for the chamber before the magazine capacity clamp.
            if (hasSeparateChamber(api) and not api:hasAmmoInBarrel()) then
                api:setAmmoInBarrel(true)
                magazine_rounds = magazine_rounds - 1
            end
            api:putAmmoInMagazine(magazine_rounds)
            reloaded_count = reloaded_count + consumed
            base_time = base_time + load_time
            cache.completed_load_time = base_time
            if (reloaded_count >= cache.needed_count or not api:hasAmmoToConsume()) then
                interrupted_time = base_time
                break
            end
        end
    end

    -- Write back cache
    if (reloaded_count >= cache.needed_count and interrupted_time == -1) then
        interrupted_time = cache.completed_load_time or reload_time
    end
    cache.interrupted_time = interrupted_time
    cache.reloaded_count = reloaded_count
    api:cacheScriptData(cache)
    -- return reloadstate
    local total_time = cache.needed_count * loop
    if (not cache.is_tactical) then
        total_time = total_time + intro
        return EMPTY_RELOAD_FEEDING, total_time - reload_time
    else
        total_time = total_time + intro
        return TACTICAL_RELOAD_FEEDING, total_time - reload_time
    end
end

function M.interrupt_reload(api)
    local cache = api:getCachedScriptData()
    if (cache ~= nil and cache.interrupted_time == -1) then
        cache.interrupted_time = api:getReloadTime()
    end
end

return M
