local M = {}

function M.shoot(api)
    api:shootOnce(api:isShootingNeedConsumeAmmo())
end

function M.start_reload(api)
    -- Initialize cache that will be used in reload ticking
    local cache = {
        reloaded_count = 0,
        needed_count = api:getNeededAmmoAmount(),
        is_tactical = api:getReloadStateType() == TACTICAL_RELOAD_FEEDING,
        interrupted_time = -1,
    }
    if(api:hasAmmoInBarrel())then
        cache.needed_count = cache.needed_count - 1
    end
    api:cacheScriptData(cache)
    -- Return true to start ticking
    return true
end

local function getReloadTimingFromParam(param)
    -- Need to convert time from seconds to milliseconds
    local intro = param.intro * 1000
    local intro_empty = param.intro_empty * 1000
    local loop = param.loop * 1000
    local ending = param.ending * 1000
    local ending_empty = param.ending_empty * 1000
    local ending_empty_feed = param.ending_empty_feed * 1000
    local clip_load = param.clip_load * 1000
    local clip_load_feed = param.clip_load_feed * 1000
    local loop_feed = param.loop_feed * 1000
    -- Check if any timing is nil
    if (intro == nil or intro_empty == nil or loop == nil or ending == nil or ending_empty == nil or ending_empty_feed == nil or clip_load == nil or clip_load_feed == nil or loop_feed == nil) then
        return nil
    end
    return intro, intro_empty, loop, ending, ending_empty, ending_empty_feed, clip_load, clip_load_feed, loop_feed
end

function M.tick_reload(api)
    -- Get all timings from script parameter in gun data
    local param = api:getScriptParams();
    local intro, intro_empty, loop, ending, ending_empty, ending_empty_feed, clip_load, clip_load_feed, loop_feed = getReloadTimingFromParam(param)
    -- Get reload time (The time from the start of reloading to the current time) from api
    local reload_time = api:getReloadTime()
    -- Get cache from api, it will be used to count loaded ammo, mark reload interruptions, etc.
    local cache = api:getCachedScriptData()
    local interrupted_time = cache.interrupted_time
    local reloaded_count = cache.reloaded_count;

    -- 参考 Kar98 的弹夹装填：空仓时在供弹时间一次性把所需弹药装入弹匣，
    -- 并保持 finishing 状态直到完整 reload_empty 动画播放结束。
    -- Luger 1906 是 open_bolt，因此这里只装弹匣，不设置膛内弹。
    if (not cache.is_tactical) then
        if (reload_time < clip_load_feed) then
            return EMPTY_RELOAD_FEEDING, clip_load_feed - reload_time
        elseif (reload_time < clip_load) then
            if (reloaded_count == 0) then
                local loaded_ammo = api:isReloadingNeedConsumeAmmo()
                    and api:consumeAmmoFromPlayer(cache.needed_count)
                    or cache.needed_count
                api:putAmmoInMagazine(loaded_ammo)
                cache.reloaded_count = cache.needed_count
                api:cacheScriptData(cache)
            end
            return EMPTY_RELOAD_FINISHING, clip_load - reload_time
        else
            return NOT_RELOADING, -1
        end
    end

    -- Handle interrupting reload
    if (cache.interrupted_time ~= -1) then
        local int_time = reload_time - cache.interrupted_time
        if(int_time >= ending) then
           return NOT_RELOADING, -1
        else
            return TACTICAL_RELOAD_FINISHING, ending - int_time
        end
    else
        if (not api:hasAmmoToConsume()) then
            interrupted_time = api:getReloadTime()
        end
    end

    -- Load the ammo into the magazine one by one
    if (reloaded_count >= 0) then
        local base_time = reloaded_count * loop + loop_feed + intro
        while (base_time < reload_time) do
            if (reloaded_count > cache.needed_count) then
                break
            end
            reloaded_count = reloaded_count + 1
            base_time = base_time + loop
            api:consumeAmmoFromPlayer(1)
            api:putAmmoInMagazine(1)
        end
    end

    -- Write back cache
    if (reloaded_count >= cache.needed_count) then
        interrupted_time = api:getReloadTime() - loop_feed + loop
    end
    cache.interrupted_time = interrupted_time
    cache.reloaded_count = reloaded_count
    api:cacheScriptData(cache)
    -- return reloadstate
    local total_time = cache.needed_count * loop + intro
    return TACTICAL_RELOAD_FEEDING, total_time - reload_time
end

function M.interrupt_reload(api)
    local cache = api:getCachedScriptData()
    if (cache ~= nil and cache.interrupted_time == -1) then
        cache.interrupted_time = api:getReloadTime()
    end
end

return M
