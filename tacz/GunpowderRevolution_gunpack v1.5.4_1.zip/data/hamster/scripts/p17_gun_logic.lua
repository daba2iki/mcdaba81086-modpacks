local M = {}

function M.start_bolt(api)
    -- Return true to start ticking, since there are nothing needed to be check
    return true
end

function M.tick_bolt(api)
    -- 调用缓存数据
    local cache = api:getCachedScriptData()
    -- 获取data中的数据
    local total_bolt_time = api:getScriptParams().bolt_time * 1000

    if (total_bolt_time == nil) then
        return false
    end
    if (api:getBoltTime() < total_bolt_time) then
        return true
    else
        if (not api:hasAmmoInBarrel() and api:removeAmmoFromMagazine(1) ~= 0) then
            api:setAmmoInBarrel(true);
        end
        return false
    end
end

function M.start_reload(api)
    -- Initialize cache that will be used in reload ticking
    local cache = {
        reloaded_count = 0,
        needed_count = api:getNeededAmmoAmount(),
        is_tactical = api:getReloadStateType() == TACTICAL_RELOAD_FEEDING,
        interrupted_time = -1,
    }
    if (api:getMaxAmmoCount() == 5) then
        if (not api:hasAmmoInBarrel()) then
            cache.needed_count = cache.needed_count + 1
        end
    elseif (api:hasAmmoInBarrel()) then
        cache.needed_count = cache.needed_count - 1
    end
    api:cacheScriptData(cache)
    -- Return true to start ticking
    return true
end

local function getReloadTimingFromParam(param)
    -- Need to convert time from seconds to milliseconds
    local intro = param.intro * 1000
    local intro_empty = param.intro_empty * 1000
    local loop = param.loop * 1000
    local ending = param.ending * 1000
    local ending_empty_feed = param.ending_empty_feed * 1000
    local clip_load = param.clip_load * 1000
    local clip_load_feed = param.clip_load_feed * 1000
    local loop_feed = param.loop_feed * 1000
    -- Check if any timing is nil
    if (intro == nil or intro_empty == nil or loop == nil or ending == nil or ending_empty_feed == nil or clip_load == nil or clip_load_feed == nil or loop_feed == nil) then
        return nil
    end
    return intro, intro_empty, loop, ending, ending_empty_feed, clip_load, clip_load_feed, loop_feed
end

function M.tick_reload(api)
    -- 获取所有装弹所需要的数据
    local param = api:getScriptParams();
    local intro, intro_empty, loop, ending, ending_empty_feed, clip_load, clip_load_feed, loop_feed = getReloadTimingFromParam(param)
    -- 获取从开始装弹到现在的时间，单位为毫秒
    local reload_time = api:getReloadTime()
    -- 调用在装弹开始时初始化写入的缓存数据
    local cache = api:getCachedScriptData()
    local interrupted_time = cache.interrupted_time
    -- Handle interrupting reload
    if (cache.interrupted_time ~= -1) then
        local int_time = reload_time - cache.interrupted_time
        if (not cache.is_tactical) then
            if (int_time > ending_empty_feed) then
                if(not api:hasAmmoInBarrel()) then
                    if (api:removeAmmoFromMagazine(1) ~= 0) then
                        api:setAmmoInBarrel(true);
                    end
                end
            end
            if(int_time >= ending) then
               return NOT_RELOADING, -1
            else
               return EMPTY_RELOAD_FINISHING, ending - int_time
            end
        else
            if(int_time >= ending) then
               return NOT_RELOADING, -1
            else
                return TACTICAL_RELOAD_FINISHING, ending - int_time
            end
        end
    else
        if (not api:hasAmmoToConsume()) then
            interrupted_time = math.max(reload_time, cache.completed_load_time or 0)
        end
    end

    local reloaded_count = cache.reloaded_count;
    -- Keep cycle timing separate from the number of rounds actually consumed.
    if (interrupted_time == -1) then
        local base_time = cache.completed_load_time
        if (base_time == nil) then
            if (not cache.is_tactical) then
                base_time = intro_empty
            else
                base_time = intro
            end
        end
        while (reloaded_count < cache.needed_count) do
            local use_clip = cache.needed_count - reloaded_count >= 5
            local feed_time = use_clip and clip_load_feed or loop_feed
            local load_time = use_clip and clip_load or loop
            if (reload_time <= base_time + feed_time) then
                break
            end
            local requested = use_clip and 5 or 1
            local consumed = api:isReloadingNeedConsumeAmmo() and api:consumeAmmoFromPlayer(requested) or requested
            if (consumed <= 0) then
                interrupted_time = reload_time
                break
            end
            local magazine_rounds = consumed
            -- Account for the chamber before filling the standard magazine.
            if (api:getMaxAmmoCount() == 5 and not api:hasAmmoInBarrel()) then
                api:setAmmoInBarrel(true)
                magazine_rounds = magazine_rounds - 1
            end
            api:putAmmoInMagazine(magazine_rounds)
            reloaded_count = reloaded_count + consumed
            base_time = base_time + load_time
            cache.completed_load_time = base_time
            if (reloaded_count >= cache.needed_count or not api:hasAmmoToConsume()) then
                interrupted_time = base_time
                break
            end
        end
    end

    -- Write back cache
    if (reloaded_count >= cache.needed_count and interrupted_time == -1) then
        interrupted_time = cache.completed_load_time or reload_time
    end
    cache.interrupted_time = interrupted_time
    cache.reloaded_count = reloaded_count
    api:cacheScriptData(cache)
    -- return reloadstate
    local total_time = cache.needed_count * loop
    if (not cache.is_tactical) then
        total_time = total_time + intro
        return EMPTY_RELOAD_FEEDING, total_time - reload_time
    else
        total_time = total_time + intro
        return TACTICAL_RELOAD_FEEDING, total_time - reload_time
    end
end

function M.interrupt_reload(api)
    local cache = api:getCachedScriptData()
    if (cache ~= nil and cache.interrupted_time == -1) then
        cache.interrupted_time = api:getReloadTime()
    end
end

return M