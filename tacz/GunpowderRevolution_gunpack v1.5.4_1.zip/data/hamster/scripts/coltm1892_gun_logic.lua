local M = {}

-- 逻辑脚本缓存会在切枪后丢失，因此将“已经退出弹壳的空膛数”持久化到枪械物品 NBT。
-- Colt 1892 使用独立字段，避免切换 SW Mk2 时相互污染弹巢状态。
-- 该值不能用 6 - 当前弹量重建：缺少的弹药既可能是仍留在弹巢中的弹壳，
-- 也可能是弹壳已经退出后的真正空膛，两者需要播放不同的装填动画。
local VACANCY_NBT_KEY = "HamsterColtM1892Vacancy"
local MAX_CYLINDER_VACANCY = 6

local function clampVacancy(value)
    value = tonumber(value) or 0
    return math.max(0, math.min(MAX_CYLINDER_VACANCY, math.floor(value)))
end

local function loadPersistentVacancy(api, fallback)
    local nbt = api:getNbt()
    if nbt:contains(VACANCY_NBT_KEY) then
        return clampVacancy(nbt:getInt(VACANCY_NBT_KEY))
    end

    -- 首次读取只继承旧缓存，不在换弹动画进行中主动修改物品 NBT。
    return clampVacancy(fallback)
end

local function storePersistentVacancy(api, value)
    local vacancy = clampVacancy(value)
    local nbt = api:getNbt()
    if not nbt:contains(VACANCY_NBT_KEY) or nbt:getInt(VACANCY_NBT_KEY) ~= vacancy then
        nbt:putInt(VACANCY_NBT_KEY, vacancy)
    end
    return vacancy
end

-- 尝试开火射击时调用
function M.shoot(api)
    local shoot_delay = api:getScriptParams().shoot_delay * 1000
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            shoot_mode = api:getFireMode() == SEMI and 1 or 0
        }
    end

    if (api:getFireMode() == SEMI) then
        shoot_delay = 0
    else
        if (cache.shoot_mode == 1) then
            shoot_delay = 0
        else
            shoot_delay = api:getScriptParams().shoot_delay * 1000
        end
    end
    -- 将执行射击的部分委托为一次性的延时任务，从而达到延迟开火的目的
    api:shootOnce(api:isShootingNeedConsumeAmmo())

    if (api:getFireMode() == SEMI) then
        cache.shoot_mode = 1
    else
        cache.shoot_mode = 0
    end
end

function M.start_reload(api)
    -- Get the cached data, ensure it's not nil
    local cache = api:getCachedScriptData()

    -- If cache is nil, initialize it to an empty table
    if cache == nil then
        cache = {}
    end

    -- Update other cache values
    cache.reloaded_count = 0
    cache.reloaded_vacancy = 0
    cache.needed_count = api:getMagExtentLevel() == 1 and 6 or api:getNeededAmmoAmount()
    -- NBT 是按枪械物品实例保存的跨切枪快照；缓存负责当前一次换弹的实时计算。
    -- 空膛数不可能大于本次缺弹数；该约束也能修复外部改弹后遗留的旧值。
    cache.vacancy = math.min(loadPersistentVacancy(api, cache.vacancy), cache.needed_count)
    -- 装弹器会连同未击发子弹一起抛弃，始终按空仓弹匣换弹处理。
    cache.is_tactical = api:getMagExtentLevel() ~= 1 and api:getReloadStateType() == TACTICAL_RELOAD_FEEDING
    cache.interrupted_time = -1
    cache.vacancyReloadTime = -1

    -- Cache the modified data
    api:cacheScriptData(cache)

    -- Return true to start ticking
    return true
end

local function getReloadTimingFromParam(param)
    -- Need to convert time from seconds to milliseconds
    local intro = param.intro * 1000
    local intro_empty = param.intro_empty * 1000
    local loop = param.loop * 1000
    local loop_empty = param.loop_empty * 1000
    local ending = param.ending * 1000
    local ending_empty = param.ending_empty * 1000
    local loop_feed = param.loop_feed * 1000
    local loop_empty_feed = param.loop_empty_feed * 1000
    local loader = param.loader * 1000
    local loader_feed = param.loader_feed * 1000
    -- Check if any timing is nil
    if (intro == nil or intro_empty == nil or loop == nil or loop_empty == nil or ending == nil or ending_empty == nil or loop_feed == nil or loop_empty_feed == nil or loader == nil or loader_feed == nil) then
        return nil
    end
    return intro, intro_empty, loop, loop_empty, ending, ending_empty, loop_feed, loop_empty_feed, loader, loader_feed
end

function M.tick_reload(api)
    -- Get all timings from script parameter in gun data
    local param = api:getScriptParams();
    local intro, intro_empty, loop, loop_empty, ending, ending_empty, loop_feed, loop_empty_feed, loader, loader_feed = getReloadTimingFromParam(param)
    -- Get reload time (The time from the start of reloading to the current time) from api
    local reload_time = api:getReloadTime()
    -- Get cache from api, it will be used to count loaded ammo, mark reload interruptions, etc.
    local cache = api:getCachedScriptData()
    local interrupted_time = cache.interrupted_time

    -- 参考 Luger 1906 的空仓装填：装弹器换弹从供弹节点开始直到整段动画结束，期间不可打断。
    if (api:getMagExtentLevel() == 1) then
        if (reload_time < loader_feed) then
            return EMPTY_RELOAD_FEEDING, loader_feed - reload_time
        elseif (reload_time < loader) then
            if (cache.reloaded_count == 0) then
                api:removeAmmoFromMagazine(6)
                local loaded_ammo = api:isReloadingNeedConsumeAmmo()
                    and api:consumeAmmoFromPlayer(cache.needed_count)
                    or cache.needed_count
                api:putAmmoInMagazine(loaded_ammo)
                cache.reloaded_count = cache.needed_count
                cache.vacancy = 0
                api:cacheScriptData(cache)
                storePersistentVacancy(api, 0)
            end
            return EMPTY_RELOAD_FINISHING, loader - reload_time
        else
            storePersistentVacancy(api, 0)
            return NOT_RELOADING, -1
        end
    end


    -- Handle interrupting reload
    if (interrupted_time ~= -1) then
        local int_time = reload_time - interrupted_time
        if (int_time >= ending) then
            storePersistentVacancy(api, cache.vacancy)
            return NOT_RELOADING, -1
        else
            if (cache.is_tactical) then
                return TACTICAL_RELOAD_FINISHING, ending - int_time
            else
                return EMPTY_RELOAD_FINISHING, ending_empty - int_time
            end
        end
    else
        -- if there is no ammo to consume, interrupt reloading
        if (not api:hasAmmoToConsume()) then
            interrupted_time = api:getReloadTime()
        end
    end

    local reloaded_count = cache.reloaded_count
    local reloaded_vacancy = cache.reloaded_vacancy
    local reload_vacancy = cache.vacancy
    local vacancyReloadTime = cache.vacancyReloadTime

    if ((not cache.is_tactical or api:getMagExtentLevel() == 1) and reloaded_count == 0) then
        if (reload_time > 1 * 1000) then
            api:removeAmmoFromMagazine(6)
        end
        reload_vacancy = 6
    end

    if (reload_vacancy ~= 0) then
        vacancyReloadTime = reloaded_count * loop_empty + loop_empty_feed
        if (not cache.is_tactical) then
            vacancyReloadTime = vacancyReloadTime + intro_empty
        else
            vacancyReloadTime = vacancyReloadTime + intro
        end
        if (api:getMagExtentLevel() == 1) then
            -- reload_loader 是一整段动画，loader_feed 对应装弹器实际送入弹药的时刻。
            vacancyReloadTime = loader_feed
        end
        if (api:getFireMode() == SEMI) then
            vacancyReloadTime = vacancyReloadTime + 0.46 * 1000
        end
        while (vacancyReloadTime < reload_time) do
            if (reloaded_count > cache.needed_count) then
                break
            end
            if (api:getMagExtentLevel() == 1) then
                reloaded_count = reloaded_count + 7
                reloaded_vacancy = 6
                reload_vacancy = 0
                api:putAmmoInMagazine(api:isReloadingNeedConsumeAmmo() and api:consumeAmmoFromPlayer(6) or 6)
            else
                reloaded_count = reloaded_count + 1
                reloaded_vacancy = reloaded_vacancy + 1
                reload_vacancy = reload_vacancy -1
                vacancyReloadTime = vacancyReloadTime + loop_empty
                api:consumeAmmoFromPlayer(1)
                api:putAmmoInMagazine(1)
            end
        end
    end

    -- Load the ammo into the magazine one by one
    if (reloaded_count >= 0 and reload_vacancy == 0) then
        local base_time = (reloaded_count - reloaded_vacancy) * loop + loop_feed + reloaded_vacancy * loop_empty
        if (not cache.is_tactical) then
            base_time = base_time + intro_empty
        else
            base_time = base_time + intro
        end
        if (api:getFireMode() == SEMI) then
            base_time = base_time + 0.46 * 1000
        end
        while (base_time < reload_time) do
            if (reloaded_count > cache.needed_count) then
                break
            end
            reloaded_count = reloaded_count + 1
            base_time = base_time + loop
            api:consumeAmmoFromPlayer(1)
            api:putAmmoInMagazine(1)
        end
    end


    -- Write back cache
    if (reloaded_count >= cache.needed_count) then
        if (api:getMagExtentLevel() == 1) then
            interrupted_time = api:getReloadTime() - loader_feed + loader
        else
            interrupted_time = api:getReloadTime() - loop_feed + loop
        end
    end
    cache.interrupted_time = interrupted_time
    cache.reloaded_count = reloaded_count
    cache.reloaded_vacancy = reloaded_vacancy
    -- 1.4.4 的动画状态机会在换弹期间逐帧维护 bullet_state。
    -- 此处只更新逻辑缓存，避免实时写 NBT 触发物品状态刷新并重置动画状态机。
    cache.vacancy = clampVacancy(reload_vacancy)
    cache.vacancyReloadTime = vacancyReloadTime
    api:cacheScriptData(cache)
    -- return reloadstate
    local total_time = (cache.needed_count - cache.vacancy) * loop + cache.vacancy * loop_empty
    if (api:getMagExtentLevel() == 1) then
        -- Colt M1892 的 reload_loader 已包含开仓、退壳、装入和闭仓，不能再叠加 intro_empty。
        total_time = loader
    end
    if (api:getFireMode() == SEMI) then
        total_time = total_time + 0.46 * 1000
    end
    if (api:getMagExtentLevel() == 1) then
        return EMPTY_RELOAD_FEEDING, total_time - reload_time
    elseif (not cache.is_tactical) then
        total_time = total_time + intro_empty
        return EMPTY_RELOAD_FEEDING, total_time - reload_time
    else
        total_time = total_time + intro
        return TACTICAL_RELOAD_FEEDING, total_time - reload_time
    end
end

function M.interrupt_reload(api)
    -- 装弹器空仓换弹严格按整段 reload_loader 播放，不响应中断。
    if (api:getMagExtentLevel() == 1) then
        return
    end
    local cache = api:getCachedScriptData()
    if (cache ~= nil) then
        cache.vacancy = storePersistentVacancy(api, cache.vacancy)
        if (cache.interrupted_time == -1) then
            cache.interrupted_time = api:getReloadTime()
        end
        api:cacheScriptData(cache)
    end
end

return M
