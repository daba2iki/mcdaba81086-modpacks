local default = require("tacz_default_state_machine")
local STATIC_TRACK_LINE = default.STATIC_TRACK_LINE
local main_track_states = default.main_track_states
local MAIN_TRACK = default.MAIN_TRACK

local idle_state = setmetatable({}, {__index = main_track_states.idle})


function idle_state.transition(this, context, input)
    if (input == INPUT_BOLT) then
        if (context:getAmmoCount() % 4 == 0) then
            context:runAnimation("bolt", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_STOP, 0.2)
        end
        return this.main_track_states.idle
    end
    return main_track_states.idle.transition(this, context, input)
end

local M = setmetatable({
    main_track_states = setmetatable({
        idle = idle_state
    }, {__index = main_track_states})
}, {__index = default})

function M:initialize(context)
    default.initialize(self, context)
end

return M