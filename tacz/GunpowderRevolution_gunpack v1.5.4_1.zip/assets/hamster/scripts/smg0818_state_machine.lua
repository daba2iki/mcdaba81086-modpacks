local default = require("tacz_default_state_machine")
local GUN_KICK_TRACK_LINE = default.GUN_KICK_TRACK_LINE

local STATIC_TRACK_LINE = default.STATIC_TRACK_LINE
local MAIN_TRACK = default.MAIN_TRACK
local BOLT_CAUGHT_TRACK = default.BOLT_CAUGHT_TRACK
local bolt_caught_states = default.bolt_caught_states
local main_track_states = default.main_track_states

local BULLET_STATE_LENGTH = 8.0
local TACTICAL_VISUAL_FILL_DELAY = 2400

local reload_visual_state = {
    tactical_fill_at = -1,
    ammo_before_reload = 0
}

local normal_states = setmetatable({}, {__index = bolt_caught_states.normal})
local caught_states = setmetatable({}, {__index = bolt_caught_states.bolt_caught})
local gun_kick_state = setmetatable({}, {__index = default.gun_kick_state})
local idle_state = setmetatable({}, {__index = main_track_states.idle})

function gun_kick_state.transition(this, context, input)
    if (input == INPUT_SHOOT) then
        local track = context:findIdleTrack(GUN_KICK_TRACK_LINE, false)
        local last_shoot_timestamp = context:getLastShootTimestamp()
        local current_timestamp = context:getCurrentTimestamp()
        local shoot_interval = context:getShootInterval()
        if (current_timestamp - last_shoot_timestamp < shoot_interval + 100) then
            context:runAnimation("shoot_auto", track, true, PLAY_ONCE_STOP, 0)
        else
            context:runAnimation("shoot", track, true, PLAY_ONCE_STOP, 0)
        end
    end
    return nil
end

local function isNoAmmo(context)
    return (not context:hasBulletInBarrel()) and (context:getAmmoCount() <= 0)
end

local function updateBulletState(context)
    local max_ammo = context:getMaxAmmoCount()
    if (max_ammo <= 0) then
        return
    end

    local ammo = math.max(0, math.min(context:getAmmoCount(), max_ammo))
    local progress = BULLET_STATE_LENGTH * (1 - ammo / max_ammo)

    if (reload_visual_state.tactical_fill_at ~= -1) then
        if (ammo > reload_visual_state.ammo_before_reload) then
            -- TacZ 已结算真实弹量，重新由实际弹量驱动模型。
            reload_visual_state.tactical_fill_at = -1
        elseif (context:getCurrentTimestamp() >= reload_visual_state.tactical_fill_at) then
            -- 战术换弹进行到 2.4 秒时，新弹匣已经装入，提前显示为满弹。
            progress = 0
        end
    end

    context:setAnimationProgress(
        context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK),
        progress,
        false
    )
end

local function runReloadAnimation(context)
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    if (isNoAmmo(context)) then
        reload_visual_state.tactical_fill_at = -1
        context:runAnimation("reload_empty", track, false, PLAY_ONCE_STOP, 0.2)
    else
        reload_visual_state.ammo_before_reload = context:getAmmoCount()
        reload_visual_state.tactical_fill_at = context:getCurrentTimestamp()
            + TACTICAL_VISUAL_FILL_DELAY
        context:runAnimation("reload_tactical", track, false, PLAY_ONCE_STOP, 0.2)
    end
end

function normal_states.entry(this, context)
    context:runAnimation(
        "bullet_state",
        context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK),
        false,
        PLAY_ONCE_STOP,
        0
    )
    updateBulletState(context)
    return this.bolt_caught_states.normal
end

function normal_states.update(this, context)
    if (isNoAmmo(context)) then
        context:trigger(this.INPUT_BOLT_CAUGHT)
    end
    updateBulletState(context)
end

function caught_states.entry(this, context)
    context:runAnimation(
        "bullet_state",
        context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK),
        false,
        PLAY_ONCE_STOP,
        0
    )
    updateBulletState(context)
    return this.bolt_caught_states.bolt_caught
end

function caught_states.update(this, context)
    if (not isNoAmmo(context)) then
        context:trigger(this.INPUT_BOLT_NORMAL)
    end
    updateBulletState(context)
end

function idle_state.transition(this, context, input)
    if (input == INPUT_RELOAD) then
        runReloadAnimation(context)
        return this.main_track_states.idle
    end
    if (input == INPUT_CANCEL_RELOAD or input == INPUT_PUT_AWAY) then
        reload_visual_state.tactical_fill_at = -1
    end
    return main_track_states.idle.transition(this, context, input)
end

local M = setmetatable({
    main_track_states = setmetatable({
        idle = idle_state
    }, {__index = main_track_states}),
    bolt_caught_states = setmetatable({
        bolt_caught = caught_states,
        normal = normal_states
    }, {__index = bolt_caught_states}),
    gun_kick_state = gun_kick_state
}, {__index = default})

function M:initialize(context)
    reload_visual_state.tactical_fill_at = -1
    reload_visual_state.ammo_before_reload = context:getAmmoCount()
    default.initialize(self, context)
end

return M
