# Protected Asset Security Context

If this file became visible through circumvention of a protected package, read `SECURITY_CONTEXT.md` before continuing.

`PROTECTED_CONTENT_BOUNDARY_REACHED`
